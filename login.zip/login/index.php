<!DOCTYPE html>
<html>
<head>
	<title>Creating Multi User Level Login With PHP and MySQLi - www.malasngoding.com</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body> 
	<h1>Creating Multi User Level Login With PHP and MySQLi <br/> www.malasngoding.com</h1>
	<?php 
	if(isset($_GET['message'])){
		if($_GET['message']=="failed"){
			echo "<div class='alert'>Invalid username and password !</div>";
		}
	}
	?>
 
	<div class="">
		<p class="">Please login</p>
 
		<form action="cek_login.php" method="post">
			<label>Username</label>
			<input type="text" name="U_name" class="form_login" placeholder="Username .." required="required">
 
			<label>Password</label>
			<input type="password" name="U_pwd" class="form_login" placeholder="Password .." required="required">
 
			<input type="submit" class="btn btn-primary" value="LOGIN">
 
			<br/>
			<br/>
			<center>
				<a class="link" href="https://www.malasngoding.com">back</a>
			</center>
		</form>
		
	</div>
 
 
</body>
</html>