<!DOCTYPE html>
<html>
<head>
	<title>page employee - www.malasngoding.com</title>
</head>
<body>
	<?php 
	session_start();

	// check whether accessing this page is logged
	if($_SESSION['U_type']==""){
		header("location:index.php?message=failed");
	}

	?>
	<h1>page employee</h1>

	<p>Halo <b><?php echo $_SESSION['U_name']; ?></b> You are already logged in as <b><?php echo $_SESSION['U_type']; ?></b>.</p>
	<a href="logout.php">LOGOUT</a>

	<br/>
	<br/>
	<a><a href="">Make Login Multi Level with PHP</a> - www.malasngoding.com</a>
</body>
</html>