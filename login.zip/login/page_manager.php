<!DOCTYPE html>
<html>
<head>
	<title>page Pengurus - www.malasngoding.com</title>
</head>
<body>
	<?php 
	session_start();

	// check apakah yang mengakses page ini sudah login
	if($_SESSION['level']==""){
		header("location:index.php?message=failed");
	}

	?>
	<h1>page Pengurus</h1>

	<p>Halo <b><?php echo $_SESSION['username']; ?></b> Anda telah login sebagai <b><?php echo $_SESSION['level']; ?></b>.</p>
	<a href="logout.php">LOGOUT</a>

	<br/>
	<br/>

	<a><a href="https://www.malasngoding.com/membuat-login-multi-user-level-dengan-php-dan-mysqli">Membuat Login Multi Level Dengan PHP</a> - www.malasngoding.com</a>
</body>
</html>







cek_login.php

<?php 
// activate session on php
session_start();

// connect php with the database connection
include 'Connection.php';

// capture data sent from the login form
//$username = $_POST['username'];
//$password = $_POST['password'];
$U_name = $_POST['U_name'];
$U_pwd = $_POST['U_pwd'];


// selecting user data with the appropriate username and password
$login = mysqli_query($Connection,"select * from user where U_name='$U_name' and U_pwd='$U_pwd'");
// calculate the amount of data found
$check = mysqli_num_rows($login);

// check whether the username and password are found in the database
if($check > 0){

	$data = mysqli_fetch_assoc($login);

	// check if the user is logged in as an admin
	if($data['level']=="admin"){

		// create a login and username session
		$_SESSION['username'] = $username;
		$_SESSION['level'] = "admin";
		// switch to the admin page dashboard
		header("location:page_admin.php");

	// check if the user login as an employee
	}else if($data['level']=="employee"){
		// create a login and username session
		$_SESSION['username'] = $username;
		$_SESSION['level'] = "employee";
		// move to employee dashboard page
		header("location:page_people.php");

	// check if the user is logged in as administrator
	// }else if($data['level']=="manager"){
	// 	// create a login and username session
	// 	$_SESSION['username'] = $username;
	// 	$_SESSION['level'] = "manager";
	// 	// switch to the administrator dashboard page
	// 	header("location:admin_page.php");
	}else{
		// switch to the login page again
		header("location:index.php?message=failed");
	}	
}else{
	header("location:index.php?message=failed");
}

?>